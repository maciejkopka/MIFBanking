<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ManageacController extends Controller
{
    public function manageac()
    {
        return view('manageac');
    }
    
}
